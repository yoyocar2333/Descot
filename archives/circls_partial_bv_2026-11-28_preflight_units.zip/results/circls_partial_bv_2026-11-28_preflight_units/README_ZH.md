# 修正前preflight：32次native編譯

物理檢查通過，但units.qec_rounds誤用作者T1_rounds（實為measurement-containing moments），因此不作主批證據。原records/journal/freeze及當時3份程式保留。修正後在新目錄重新freeze並跑32次。
